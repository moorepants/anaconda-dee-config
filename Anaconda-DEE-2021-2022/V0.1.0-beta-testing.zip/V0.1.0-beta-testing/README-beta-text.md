# README Beta test Aug 5, 2021

Kevin Geboers, Bart Gerritsen

Teams session, Aug 5, 2021, 11.15h

Anaconda 2021.05 Individual Edition as specified in the Proposal, Installation Procedure.

## Testing activities

1. installed testscript (ref. ``tests.zip`)

1. launched Anaconda Powershell

1. ran: `test_package_loading.py` V0.1.0 script for beta test

1. compile the results in: `TESTLOG_DUT_20210805_11_15.log`

1. analyzed the latter `*.log` file, with `TESTLOG.log` (ran on on-site dev installation of Anaconda) as a reference

